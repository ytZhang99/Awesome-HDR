%% This script is for the edit of the result right before.

clear all;clc;
load('Config.mat', 'PROG');

if exist(fullfile('Data',PROG.DATANAME,'Radio', 'LinearizedImg.mat'),'file') == 0
	disp('Please try main.m script first!');
	return;
end

%% Process 2. Mask Generation
cd 2_Mask;
main;
cd ..;

%% Process 3. Rank Minimization
cd 3_Lowrank;
main;
cd ..;

%% Process 4. Simple Composition
cd 4_Composition;
main;
cd ..;