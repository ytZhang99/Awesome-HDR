function [ sat_mask ] = fn_satmask( curimg, thr )
%FN_SATMASK Summary of this function goes here
%   Detailed explanation goes here

    sat_mask = (curimg < thr) | (curimg > 1-thr);
    sat_mask = im2uint8(sat_mask);
end

