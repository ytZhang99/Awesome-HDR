function image_lin = applyCRF( image, CRF )

g_x = linspace(0,1,256);
image_lin = min(1,max(0, image) );
for i=1:3
    image_lin(:,:,i) = interp1(g_x, CRF{i}, image_lin(:,:,i), 'spline');
end
