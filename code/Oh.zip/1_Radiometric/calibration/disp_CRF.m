function [h] = disp_CRF( crf_ours )
%DISP_CRF Summary of this function goes here
%   Detailed explanation goes here
    h = figure;
    
    colormat = eye(3);
    
    for i = 1:3
        subplot(1,3,i);
        plot(0:1/255:1, crf_ours{i},'Color',colormat(:,i));
        axis equal;
        axis([0 1 0 1]);
        
        grid on;
    end
    
    drawnow;
end

