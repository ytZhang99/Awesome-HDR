function est_y_final = do_calibration( obs, exposure, method )

if nargin < 3
    method = 'JYLEE';
end

n_trials = 5;
samplingNumber = 1000;

g_x = linspace(0,1,256);
est_y = zeros(n_trials,256);

for i = 1:n_trials
    disp(['trial - ' num2str(i)]);

    args = [];
    args.obs_mat = obs(unique(randi(size(obs,1), [1 samplingNumber])), :);
    args.exposure = exposure;
    args.n_poly = 6;
    if strcmp(method,'JYLEE')
        res = RankMinCalibrationPolyRobust(args);
    else
        res = Mitsunaga(args);
    end

    est_y(i,:)  = max(0, min(1, polyval(res.coeff, g_x))) .^ res.gamma;
end

est_y_final = median(est_y,1);
