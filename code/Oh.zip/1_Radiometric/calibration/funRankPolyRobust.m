function cost = funRankPolyRobust(obs_mat, tau, tau2)

coeff = para2tfm(tau);
Dotau = polyval(coeff, obs_mat);

A = Dotau;
for iter=1:50
    [U S V] = svd(A, 'econ');
    low_rank = U(:,1) * S(1) * V(:,1)';
    high_rank = A-low_rank;
    avg = mean(high_rank(:));
    st = std(high_rank(:));
    dE = (abs(high_rank-avg) > 0.0075+tau2*st) .* high_rank;
    A = A - dE;
    if norm(dE) < 1e-7
        break;
    end
end

A = min(1,max(0,A));
S = svd(A, 'econ');
rank_cost = S(2) / S(1);

% monotonicity constraint
step = 1/100;
step_min = 0;
x = 0:step:1;
y = polyval(coeff, x);
dy = y(2:end) - y(1:end-1);
mono_cost = sum(dy<step_min);

cost = [rank_cost; 1e10*mono_cost ];


