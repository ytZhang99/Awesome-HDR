function [candidate_all, candidate_set] = extract_data_from_real_images(datadir, filelist, nChannel, param)

if ~isfield(param, 'trimRatio')
    param.trimRatio = 1;
end
if ~isfield(param, 'saturationLevel')
    param.saturationLevel = 252/255;
end
if ~isfield(param, 'noiseLevel')
    param.noiseLevel = 3/255;
end
if ~isfield(param, 'windowStd')
    param.windowStd = 0.03;
end
if ~isfield(param, 'autoSelectAcceptThres')
    param.autoSelectAcceptThres = 0.3;
end
if ~isfield(param, 'resizeWidth')
    param.resizeWidth = 640;
end
if ~isfield(param, 'showMask')
    param.showMask = false;
end
if ~isfield(param, 'zero_bias')
    param.zero_bias = [0 0 0];
end
if ~isfield(param, 'colorSaturation')
    param.colorSaturation = 0.5;
end
n_images = numel(filelist);

%% load images & pre-calculation
input_images = cell(n_images,3);

for i=1:n_images
    % read image
    img_read = im2uint8(imread(fullfile(datadir, filelist{i})));
    img_hsv = rgb2hsv(img_read);
    img_read = img_read(:,:,nChannel) - param.zero_bias(nChannel);
    img_read = single(img_read) / (255 - param.zero_bias(nChannel));

    % trim image
    trim_tl = max([1,1], round(size(img_read) * (0.5-param.trimRatio/2)));
    trim_br = min(size(img_read), round(size(img_read) * (0.5+param.trimRatio/2)));
    img_read = img_read(trim_tl(1):trim_br(1), trim_tl(2):trim_br(2));
    img_hsv = img_hsv(trim_tl(1):trim_br(1), trim_tl(2):trim_br(2), :);

    % calc mean image from original scale
    img_mean = imfilter(img_read,ones(3,3)) / 9.0;
    img_sq_mean = imfilter(img_read.^2,ones(3,3)) / 9.0;
    img_std = sqrt( img_sq_mean - img_mean.^2 );
    
    % resize image
    if param.resizeWidth > 0 && param.resizeWidth > size(img_mean,2)
        resize_scale = param.resizeWidth / size(img_mean,2);
        img_mean = imresize(img_mean, resize_scale, 'nearest');
        img_std = imresize(img_std, resize_scale, 'nearest');
        img_hsv = imresize(img_hsv, resize_scale, 'nearest');
    end
    
    % store image
    input_images{i,1} = img_mean;
    input_images{i,2} = img_std;
    input_images{i,3} = img_hsv(:,:,2) < param.colorSaturation;
end

%% find candidate pixels
n_pix = numel(input_images{i,1});
pix_ok = cell(n_images, 1);
n_ok = zeros(n_images, 1);
for i=1:n_images
    img_mean = input_images{i,1};
    img_std = input_images{i,2};
    img_saturation = input_images{i,3};

    pix_ok{i} = find( (img_mean >= param.noiseLevel) & (img_mean <= param.saturationLevel) & (img_std < param.windowStd) & img_saturation );
    n_ok(i) = numel(pix_ok{i});
end
candidate_set = find( n_ok > n_pix * param.autoSelectAcceptThres );
%%
test_ok = 1:n_pix;
for i=1:numel(candidate_set)
    test_ok = intersect(test_ok, pix_ok{candidate_set(i)});
    if i<numel(candidate_set)
        img_mean1 = input_images{candidate_set(i),1};
        img_mean2 = input_images{candidate_set(i+1),1};
        test_ratio = find(img_mean1 ./ img_mean2 <= 1);
        test_ok = intersect(test_ok, test_ratio);
    end
end

%%
candidate_all = zeros(numel(test_ok), numel(candidate_set));
for i=1:numel(candidate_set)
    img_mean = input_images{candidate_set(i),1};
    candidate_all(:,i) = img_mean(test_ok);
end


disp([num2str(n_pix) ' / ' num2str(numel(test_ok))]);
if param.showMask    
    lookup = false(size(input_images{1,1}));
    lookup(test_ok) = 1;
    figure;
    imshow(lookup);
    drawnow;
%     pause;
end
