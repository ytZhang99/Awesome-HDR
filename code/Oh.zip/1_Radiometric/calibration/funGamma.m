function cost = funGamma(Dotau, exposure, gamma)

Dotau_gamma = Dotau .^ gamma;
nExposure = numel(exposure);
% nRatios = numel(exposure)-1;
cost = zeros(size(Dotau,1), nExposure*3);

idx = 0;
for i=1:nExposure-1
    for j=i+1:min(nExposure,i+3)
        if exposure(i) / exposure(j) >= 0.1
            idx = idx + 1;
            cost(:,idx) = ( Dotau_gamma(:,i) * exposure(j) - Dotau_gamma(:,j) * exposure(i) );
        end
    end
end

cost = cost(:,1:idx);