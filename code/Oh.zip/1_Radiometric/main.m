clear all; close all; clc;
addpath(genpath('.'));


FLAG_ADJUSTEXP = 0; 

load('../Config.mat');
PROG.EXPNAME = 'Radio';
KEYWORD = PROG.RadioMethod;


curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
savepath = fullfile(curpath, PROG.EXPNAME);
maskpath = fullfile(curpath,'Mask');
mkdir(savepath);
mkdir(maskpath);

%% Load exposure
exposure = dlmread(fullfile(curpath, 'ev.txt'));
exposure = 1./exposure(1,:);

%% Load images
FileList = getFilelist_nr(curpath, {'jpg', 'png', 'tif', 'tiff', 'bmp'});
nimgs = length(FileList);
RED = 1;    GREEN = 2;  BLUE = 3;
cellimgs = cell(1,3);
cellimgs{RED} = cell(1,nimgs);
cellimgs{GREEN} = cell(1,nimgs);
cellimgs{BLUE} = cell(1,nimgs);

for i = 1:nimgs
    curimg = imread(FileList{i});
    type = class(curimg);
    if (strcmp(type, 'uint8'))
        maxImVal = 255;
    elseif (strcmp(type, 'uint16'))
        maxImVal = 2^16 - 1;
    end
        
    curimg = double(curimg)./maxImVal;
    cellimgs{RED}{i} = curimg(:,:,RED);
    cellimgs{GREEN}{i} = curimg(:,:,GREEN);
    cellimgs{BLUE}{i} = curimg(:,:,BLUE);
    
    % Save saturation mask
    sat_mask = fn_satmask( curimg, PROG.saturation_thr );
    imwrite(sat_mask, fullfile(maskpath, ['Sat' num2str(i) '.png']));
end
imgsize = size(curimg);

%% Radiometric calibration
flist = cell(1,nimgs);
for i = 1:nimgs
    curstr = regexp(FileList{i},'\/','split');
    flist{i} = curstr{end};
end

disp(['Radiometric calibration by ' KEYWORD ' method.']);
crf_ours = cell(3,1);
for nChannel = 1:3
    [candidate_all,candidate_set] = extract_data_from_real_images(curpath, flist, nChannel, []);
    myexposure = exposure(candidate_set);
    
    crf_ours{nChannel} = do_calibration( candidate_all, myexposure, KEYWORD );
end
disp_CRF(crf_ours);
save(fullfile(savepath, 'CRF.mat'), 'crf_ours', 'exposure', 'KEYWORD');



%% Construct data matrix
cell_linearized_img = cell(1,3);
for ich = RED:BLUE
    cell_linearized_img{ich} = cell(1,nimgs);
    for j = 1:nimgs
        cell_linearized_img{ich}{j} = fn_ldr2irr(cellimgs{ich}{j}, crf_ours{ich}, exposure(j));
    end
end

save(fullfile(savepath, 'LinearizedImg.mat'), 'cell_linearized_img', 'cellimgs');

close all;
for j = 1:nimgs
    ich = RED;
    R = fn_irr2ldr(cell_linearized_img{ich}{j}, crf_ours{ich}, exposure(round(end/2)));
    ich = GREEN;
    G = fn_irr2ldr(cell_linearized_img{ich}{j}, crf_ours{ich}, exposure(round(end/2)));
    ich = BLUE;
    B = fn_irr2ldr(cell_linearized_img{ich}{j}, crf_ours{ich}, exposure(round(end/2)));
    imshow( cat(3,R,G,B) );
    drawnow;
    pause(1);
end

