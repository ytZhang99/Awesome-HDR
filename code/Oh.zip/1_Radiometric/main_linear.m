clear all; close all; clc;
addpath(genpath('.'));

FLAG_CALIB = 1;
FLAG_ADJUSTEXP = 0; 

load('../Config.mat');

PROG.EXPNAME = 'Radio';
KEYWORD = 'Linear';


curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
savepath = fullfile(curpath, PROG.EXPNAME);
mkdir(savepath);

%% Load exposure
exposure = dlmread(fullfile(curpath, 'ev.txt'));
exposure = 1./exposure(1,:);

%% Load images
FileList = getFilelist_nr(curpath, {'jpg', 'png', 'tif', 'tiff', 'bmp'});
nimgs = length(FileList);
RED = 1;    GREEN = 2;  BLUE = 3;
cellimgs = cell(1,3);
cellimgs{RED} = cell(1,nimgs);
cellimgs{GREEN} = cell(1,nimgs);
cellimgs{BLUE} = cell(1,nimgs);
cell_linearized_img = cell(1,3);

for i = 1:nimgs
    curimg = imread(FileList{i});
    type = class(curimg);
    if (strcmp(type, 'uint8'))
        maxImVal = 255;
    elseif (strcmp(type, 'uint16'))
        maxImVal = 2^16 - 1;
    end
        
    curimg = double(curimg)./maxImVal;
    cellimgs{RED}{i} = curimg(:,:,RED);
    cellimgs{GREEN}{i} = curimg(:,:,GREEN);
    cellimgs{BLUE}{i} = curimg(:,:,BLUE);
    cell_linearized_img{RED}{i} = curimg(:,:,RED)./exposure(i);
    cell_linearized_img{GREEN}{i} = curimg(:,:,GREEN)./exposure(i);
    cell_linearized_img{BLUE}{i} = curimg(:,:,BLUE)./exposure(i);
    
    % Save saturation mask
    sat_mask = fn_satmask( curimg, PROG.saturation_thr );
    imwrite(sat_mask, fullfile(maskpath, ['Sat' num2str(i) '.png']));
end
imgsize = size(curimg);
disp(['Bypass the radiometric calibration by ' KEYWORD ' method.']);

crf_ours{1} = 0:1/255:1;
crf_ours{2} = 0:1/255:1;
crf_ours{3} = 0:1/255:1;
crf_mn = crf_ours;

disp_CRF(crf_ours);
disp_CRF(crf_mn);
save(fullfile(savepath, 'CRF.mat'), 'crf_ours', 'crf_mn', 'exposure', 'KEYWORD');
    

%% Construct data matrix

save(fullfile(savepath, 'LinearizedImg.mat'), 'cell_linearized_img', 'cellimgs');


