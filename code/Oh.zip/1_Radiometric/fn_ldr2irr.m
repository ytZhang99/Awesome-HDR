function [ irr ] = fn_ldr2irr( ldr, CRF, exposure )
%FN_LDR2IRR Summary of this function goes here
%   Detailed explanation goes here
     Data = interp1(0:1/255:1, CRF, ldr, 'spline');
     irr = Data./exposure;

end

