function [ ldr ] = fn_irr2ldr( irr, CRF, exposure )
%FN_IRR2LDR Summary of this function goes here
%   Detailed explanation goes here

    ldr = interp1(CRF, 0:1/255:1, irr.*exposure, 'spline');
    

end

