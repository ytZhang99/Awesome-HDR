% ========================================================================
% Robust High Dynamic Range Imaging by Rank Minimization, Version 0.9
%
% Please refer to the following our paper:
%
% Tae-Hyun Oh, Joon-Young Lee, Yu-Wing Tai, In So Kweon,
% 	"Robust High Dynamic Range Imaging by Rank Minimization," 
% 	submitted to IEEE Transactions on Pattern Analysis and Machine 
%	Intelligence (TPAMI), 2014.
% Tae-Hyun Oh, Joon-Young Lee, In So Kweon,
% 	"High Dynamic Range Imaging by a Rank-1 Constraint," 
%	IEEE International Conference on Image Processing (ICIP), 2013.
%
%
% Please cite our paper if you use any part of the code.
% If you find any bug, please contact thoh.kaist.ac.kr@gmail.com.
%
% ----------------------------------------------------------------------
% Permission to use, copy, or modify this software and its documentation
% for educational and research purposes only and without fee is here
% granted, provided that this copyright notice and the original authors'
% names appear on all copies and supporting documentation. This program
% shall not be used, rewritten, or adapted as the basis of a commercial
% software or hardware product without first obtaining permission of the
% authors. The authors make no representations about the suitability of
% this software for any purpose. It is provided "as is" without express
% or implied warranty.
%----------------------------------------------------------------------

[Dependencies]
Our implementation is based on the below libraries
- Radiometric calibration: library of the paper [1].
		refer to the README file in "./1_Radiometric/calibration"


- VLFeat 0.9.18 [2]: a direct copy of the "toolbox" folder from the library.
		 refer to COPYRIGHT and README file in "./2_Mask/toolbox"



[Description]
For demo, 
	- download the Waterfall dataset and copy them to 'Data/WaterFall2' folder.
	- Excute main.m.
	- If want to revise the previous result, excute retry.m
There are some options for each step. Check the below descriptions.

** Notice: we assume that the filenames of input LDRs are ordered 
by exposure in ascending order.



1. Radiometric Calibration
: To linearize the input image. It generate 'camera response functions'
for RGB channels, and provide calibrated matrices. There are two options.
    - main_linear: When the inputs are already calibrated.
    - main: When the radiometric calibration is required [1].


2. Segmentation
: This generate 'mask.mat' and Mask images. We provide simple GUI
based on the oversegmentation technique [3]. 
Please refer to the quick instruction for the usages.



3. Rank Minimization
: The matrix completion algorithm by minimizing the partial sum of
 singular values. The optimization algorithm is based on ADMM. 
For the details, please refer to our paper.
It provides low-rank decomposed image and sparse outlier matrix.
In our all experiments, we fix all the parameters of ADMM.
However, we cannot guarantee that the parameters always produce 
the best results. So, if you want more faster convergence speed 
or high quality results, you can adjust the parameter properly.


4. Composition
: This provides a '.hdr' format HDR image and a tone-mapped result.
We apply the most simple methods; For the composition, the average 
of the recovered radiances is used. For the tone-mapping, Matlab 
built-in 'tonemap()' function is used.





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Release Note
14.08.08> Initial demo source is provided. 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% References
[1] Lee et. al., "Radiometric Calibration by Rank Minimization",
IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI), 2013.
[2] A. Vedaldi and B. Fulkerson. VLFeat Library. http://www.vlfeat.org/
[3] Achanta et. al.,SLIC Superpixels Compared to State-of-the-art Superpixel Methods, 
IEEE Transactions on Pattern Analysis and Machine Intelligence (TPAMI), 2012.

