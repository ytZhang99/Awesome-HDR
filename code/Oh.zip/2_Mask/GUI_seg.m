function varargout = GUI_seg(varargin)
% GUI_SEG MATLAB code for GUI_seg.fig
%      GUI_SEG, by itself, creates a new GUI_SEG or raises the existing
%      singleton*.
%
%      H = GUI_SEG returns the handle to a new GUI_SEG or the handle to
%      the existing singleton*.
%
%      GUI_SEG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_SEG.M with the given input arguments.
%
%      GUI_SEG('Property','Value',...) creates a new GUI_SEG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_seg_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_seg_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_seg

% Last Modified by GUIDE v2.5 20-Aug-2014 17:43:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_seg_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_seg_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if length(varargin) < 3
    disp('GUI] Input and output path must be designated!');
    disp('GUI] Input LDR images must be given!');
    disp('GUI] Input saturation mask must be given!');
    return;
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_seg is made visible.
function GUI_seg_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_seg (see VARARGIN)
    
    
%% Initialization of GUI
    %% Parameters
        global g_para_seg;
        g_para_seg.regionSz = 15;
        g_para_seg.regularizer = 0.02;
        set(handles.edit_para_spartial, 'String', num2str(g_para_seg.regionSz));
        set(handles.edit_para_regular, 'String', num2str(g_para_seg.regularizer));
        
        global g_brushidx;
        g_brushidx = 1;
        set(handles.sttext_brushidx, 'String', num2str(g_brushidx));

        global g_bincludesaturation;
        g_bincludesaturation = true;
        set(handles.checkbox_saturation, 'Value', g_bincludesaturation);
        
    %% Path configuration
        global g_struct_path;
        PROG = varargin{1};
        g_struct_path.curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
        g_struct_path.inputpath = fullfile(g_struct_path.curpath, PROG.INPUTPATH);
        g_struct_path.savepath = fullfile(g_struct_path.curpath, PROG.EXPNAME);

    %% Brush viewer
        global g_LDRimgs g_Nimg;
        g_Nimg = length(varargin{2});
        brushimgs = cat(2, varargin{2}{:});
        g_LDRimgs = varargin{2};
        
        himage = imshow(brushimgs, 'Parent', handles.axes1);
        set(himage, 'ButtonDownFcn', {@axes1_ButtonDownFcn, handles});
    
   
        
    %% Oversegmentation
        global g_struct_segment;
        g_struct_segment.segment = cell(1, g_Nimg);
        g_struct_segment.edgemap = cell(1, g_Nimg);
        disp('GUI] Processing oversegmentation...');
        for i = 1:g_Nimg
            fprintf('\r%d th image...', i);
            [ g_struct_segment.segment{i}, g_struct_segment.edgemap{i}] = fn_seg( g_LDRimgs{i}, g_para_seg.regionSz, g_para_seg.regularizer );
        end
        fprintf('\n');
%         save('temp.mat', 'g_struct_segment');
%         load('temp.mat', 'g_struct_segment');
        g_struct_segment.regionSz = g_para_seg.regionSz;
        g_struct_segment.regularizer = g_para_seg.regularizer;
        global g_bshowseggrid;
        g_bshowseggrid = true;
        fn_displayboundary(g_bshowseggrid, handles);
        set(handles.checkbox_showseggrid, 'Value', g_bshowseggrid);
        
    %% Scribble viewer
        global g_colormap g_struct_curscribble;
        g_colormap = jet(g_Nimg);
        g_struct_curscribble.bmap = [];
        g_struct_curscribble.idx = 0;
        
        
    %% Mask previewer
        global g_cell_mask g_cell_satmask;
        g_cell_satmask = varargin{3};
        g_cell_mask = g_cell_satmask;
        curmask = cat(1, g_cell_mask{:});
        imshow(curmask, 'Parent', handles.axes_Mask_preview);
        
        
% Choose default command line output for GUI_seg
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_seg wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_seg_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
% disp('Press any key to continue...');
varargout{1} = handles.output;


% --- Executes on mouse press over axes background.
% function axes_WDR_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over axes background.
function axes1_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g_Nimg g_brushidx g_bshowseggrid;
    axesHandle  = get(hObject,'Parent');
    coordinates = get(axesHandle,'CurrentPoint'); 
%     coordinates = coordinates(1,1:2); % X, Y
    pimg = get(hObject, 'CData');
    selected_img_idx = floor(coordinates(1)./size(pimg, 2)*g_Nimg) + 1;
    g_brushidx = selected_img_idx;
    set(handles.sttext_brushidx, 'String', num2str(selected_img_idx));
    
    % Display
    fn_displayboundary(g_bshowseggrid, handles);
    guidata(hObject, handles);
    

% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on button press in pushbutton_do_overseg.
function pushbutton_do_overseg_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_do_overseg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_para_seg g_LDRimgs g_struct_segment g_bshowseggrid g_Nimg;
%     g_para_seg
    disp('GUI] Processing oversegmentation...');
    diff = [abs(g_struct_segment.regionSz - g_para_seg.regionSz);
            abs(g_struct_segment.regularizer - g_para_seg.regularizer)];
    disp(g_para_seg);
    if max(diff) > eps
        g_struct_segment.regionSz = g_para_seg.regionSz;
        g_struct_segment.regularizer = g_para_seg.regularizer;
        for i = 1:g_Nimg
            fprintf('\r%d th image...', i);
            [ g_struct_segment.segment{i}, g_struct_segment.edgemap{i}] = fn_seg( g_LDRimgs{i}, g_para_seg.regionSz, g_para_seg.regularizer );
        end
        fprintf('\n');
        disp('GUI] Finish oversegmentation...');
        fn_displayboundary(true, handles);
        g_bshowseggrid = true;
        set(handles.checkbox_showseggrid, 'Value', true);
    else
        disp('Oversegmentation] Already segmented!');
    end
    
    
    

function edit_para_regular_Callback(hObject, eventdata, handles)
% hObject    handle to edit_para_regular (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
        global g_para_seg;
        g_para_seg.regularizer = str2double(get(hObject,'String'));
        disp(g_para_seg);
% Hints: get(hObject,'String') returns contents of edit_para_regular as text
%        str2double(get(hObject,'String')) returns contents of edit_para_regular as a double


% --- Executes during object creation, after setting all properties.
function edit_para_regular_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_para_regular (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_para_spartial_Callback(hObject, eventdata, handles)
% hObject    handle to edit_para_spartial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_para_seg;
    g_para_seg.regionSz = str2double(get(hObject,'String'));
    disp(g_para_seg);
% Hints: get(hObject,'String') returns contents of edit_para_spartial as text
%        str2double(get(hObject,'String')) returns contents of edit_para_spartial as a double


% --- Executes during object creation, after setting all properties.
function edit_para_spartial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_para_spartial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_showseggrid.
function checkbox_showseggrid_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_showseggrid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_bshowseggrid;
    g_bshowseggrid = get(hObject,'Value');
    fn_displayboundary(g_bshowseggrid, handles);

% Hint: get(hObject,'Value') returns toggle state of checkbox_showseggrid


function fn_displayboundary(bshow, handles)
    global g_LDRimgs g_struct_segment g_curscribbleview g_brushidx;
    if bshow
        g_curscribbleview = g_LDRimgs{g_brushidx};
        % Draw boundary
        g_curscribbleview = fn_alphamixing(g_curscribbleview, g_struct_segment.edgemap{g_brushidx}, [1 0 1], 0.1);
        imshow(g_curscribbleview, 'Parent', handles.axes_WDR);
    else
        g_curscribbleview = g_LDRimgs{g_brushidx};
        imshow(g_curscribbleview, 'Parent', handles.axes_WDR);
    end

    
    
% --- Executes on button press in checkbox_saturation.
function checkbox_saturation_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_saturation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_cell_mask g_cell_satmask g_Nimg g_bincludesaturation;
    g_bincludesaturation = get(hObject,'Value');
    
    if g_bincludesaturation == 0
%         g_cell_mask = cell(g_Nimg,1);
        for i = 1:g_Nimg
            g_cell_mask{i} = ones(size(g_cell_mask{1},1), size(g_cell_mask{1},2), 3);
        end
    else
        g_cell_mask = g_cell_satmask;
    end
    curmask = cat(1, g_cell_mask{:});
    imshow(curmask, 'Parent', handles.axes_Mask_preview);
% Hint: get(hObject,'Value') returns toggle state of checkbox_saturation


% --- Executes on button press in pushbutton_reset.
function pushbutton_reset_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_cell_mask g_Nimg g_bincludesaturation;
    %g_cell_mask = cell(g_Nimg,1);
    for i = 1:g_Nimg
        g_cell_mask{i} = ones(size(g_cell_mask{1},1), size(g_cell_mask{1},2), 3);
    end
    curmask = cat(1, g_cell_mask{:});
    imshow(curmask, 'Parent', handles.axes_Mask_preview);
    g_bincludesaturation = false;
    set(handles.checkbox_saturation, 'Value', g_bincludesaturation);

    

% --- Executes on button press in pushbutton_load_mask.
function pushbutton_load_mask_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_load_mask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_struct_path g_cell_mask;
    fname = fullfile(g_struct_path.savepath, 'Mask.mat');
    if exist(fname, 'file') > 0
        load(fname, 'cell_objmask');
        g_cell_mask = cell_objmask';
        curmask = cat(1, g_cell_mask{:});
        imshow(curmask, 'Parent', handles.axes_Mask_preview);
	else
		disp('GUI] No saved mask exists.');
    end
    
% --- Executes on button press in pushbutton_done.
function pushbutton_done_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_done (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_Nimg g_cell_mask g_struct_path;
	g_cell_mask = fn_make_feasible( g_cell_mask );
    path_output = g_struct_path.savepath;
    mkdir(path_output);
    for i = 1:g_Nimg
        imwrite(g_cell_mask{i}, fullfile(path_output, ['OM' num2str(i) '.png']));
    end
    cell_objmask = g_cell_mask';
    save(fullfile(path_output, 'Mask.mat'), 'cell_objmask');
%     disp('Press any key to continue...');
    delete(handles.figure1);



    %% 
    %% Scribble related functions
    %% 
% --- Executes on button press in pushbutton_apply_minus.
function pushbutton_apply_minus_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply_minus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_struct_curscribble g_cell_mask g_Nimg;
    curidx = g_struct_curscribble.idx;
    if curidx > 0 && curidx <= g_Nimg
        g_cell_mask{curidx} = single(g_cell_mask{curidx} & repmat(~g_struct_curscribble.bmap, [1 1 3]));
        curmask = cat(1, g_cell_mask{:});
        imshow(curmask, 'Parent', handles.axes_Mask_preview);
    end
    

% --- Executes on button press in pushbutton_apply_plus.
function pushbutton_apply_plus_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply_plus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_struct_curscribble g_cell_mask g_Nimg;
    curidx = g_struct_curscribble.idx;
    if curidx > 0 && curidx <= g_Nimg
        g_cell_mask{curidx} = single(g_cell_mask{curidx} | repmat(g_struct_curscribble.bmap,[1 1 3]));
        curmask = cat(1, g_cell_mask{:});
        imshow(curmask, 'Parent', handles.axes_Mask_preview);
    end

    
% --- Executes on button press in pushbutton_apply_propa.
function pushbutton_apply_propa_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_apply_propa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_struct_curscribble g_cell_mask g_Nimg;
    curidx = g_struct_curscribble.idx;
    if curidx > 0 && curidx <= g_Nimg
        curbmap = repmat(g_struct_curscribble.bmap, [1 1 3]);
        g_cell_mask{curidx} = single(g_cell_mask{curidx} | curbmap);
        
        idx_propa = 1:g_Nimg;   idx_propa(curidx) = [];
        curbmap = ~curbmap;
        for i = idx_propa
            g_cell_mask{i} = single(g_cell_mask{i} & curbmap);
        end
        
        curmask = cat(1, g_cell_mask{:});
        imshow(curmask, 'Parent', handles.axes_Mask_preview);
    end

% --- Executes on button press in pushbutton_drawmark.
function pushbutton_drawmark_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_drawmark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global g_colormap g_brushidx g_struct_curscribble g_curscribbleview g_struct_segment;
    axes(handles.axes_WDR);
%     scribbleimg = g_LDRimgs;
%     imshow(scribbleimg, 'Parent', handles.axes_WDR);
    g_struct_curscribble.bmap = roipoly(g_curscribbleview);
    g_struct_curscribble.idx = g_brushidx;
    
    selected_segments = g_struct_segment.segment{g_brushidx}(g_struct_curscribble.bmap);
    selected_segments = unique(selected_segments);
    g_struct_curscribble.bmap = ismember(g_struct_segment.segment{g_brushidx}, selected_segments);
    
    % display current markup result
    curcolor = g_colormap(g_brushidx, :);
    scribbleimg = fn_alphamixing( g_curscribbleview, g_struct_curscribble.bmap, curcolor, 0.6 );
    imshow(scribbleimg, 'Parent', handles.axes_WDR);
    
