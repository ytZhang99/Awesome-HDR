function [ segments, edgemap ] = fn_seg( img, regionSize, regularizer )
%FN_SEG �� �Լ��� ��� ���� ��ġ
%   �ڼ��� ���� ��ġ

    img = im2single(img);
    labimg = vl_xyz2lab(vl_rgb2xyz(img));
    L = labimg(:,:,1)./100;
    a = labimg(:,:,2)./64;
    b = labimg(:,:,3)./64;
    labimg = single(cat(3, L, a, b));

%     tic;
    segments = vl_slic(labimg, regionSize, regularizer) ;
%     toc;
    if nargout > 1
        singleseg = single(segments);

        dx = imfilter(singleseg,[1 -1],'replicate');
        dy = imfilter(singleseg,[1 -1]','replicate');
        Gmag = sqrt(dx.^2 + dy.^2); 
        edgemap = Gmag ~= 0;
    end
    
end

