clear all; close all; clc;
% addpath(genpath('.'));
cd toolbox; vl_setup; cd ..;

%% Set parameters
PARA.Gamma = 0.3;

%% Load settings
load('../Config.mat');
PROG.EXPNAME = 'Mask';
PROG.INPUTPATH = 'Radio';

curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
inputpath = fullfile(curpath, PROG.INPUTPATH);
savepath = fullfile(curpath, PROG.EXPNAME);


%% Load exposure
exposure = dlmread(fullfile(curpath, 'ev.txt'));
exposure = 1./exposure(1,:);

load(fullfile(inputpath, 'LinearizedImg.mat')); % < Original & Linearized Imgs >
                                                % cell_linearized_img{CH}{NIMG}
                                                % cellimgs{CH}{NIMG}

st_imginfo.imsize = size(cellimgs{1}{1});
st_imginfo.nimg = length(cellimgs{1});
st_imginfo.expt_ref = exposure(round(end/2));

[PseudoWDR, uncertaintymap] = fn_pwdr( cell_linearized_img, st_imginfo.expt_ref, PARA.Gamma );
% imagesc(min(uncertaintymap, 10))
% axis image;

cell_satmask = fn_load_satmask(savepath);
Brush_img = fn_lin2ldr(cell_linearized_img, exposure, PARA.Gamma);

h = GUI_seg(PROG, Brush_img, cell_satmask);
waitfor(h);

disp('Finish the GUI!');





