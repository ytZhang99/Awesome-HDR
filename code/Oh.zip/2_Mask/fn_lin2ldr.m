function [ cell_ldrimgs ] = fn_lin2ldr( cell_3ch_imgs, exps, gamma )
%FN_LIN2LDR Summary of this function goes here
%   Detailed explanation goes here
    
    if nargin < 3
        gamma = 0.5;
    end

    nimg = length(cell_3ch_imgs{1});
    cell_ldrimgs = cell(1,nimg);
    for i = 1:nimg
        R = cell_3ch_imgs{1}{i};
        G = cell_3ch_imgs{2}{i};
        B = cell_3ch_imgs{3}{i};
        cell_ldrimgs{i} = (max(0, cat(3,R, G, B).*exps(i))).^gamma;
    end
end

