function [ cell_objmask ] = fn_make_feasible( cell_objmask )
%FN_MAKE_FEASIBLE Summary of this function goes here
%   Detailed explanation goes here

    nimgs = length(cell_objmask);
    
    mask4d = cat(4, cell_objmask{:});
    nknown3d = sum(mask4d, 4);
    
    for ich = 1:3
        curvotemask = nknown3d(:,:,ich);
        flag = (curvotemask == 0);
        
        if sum(flag(:)) > 0
            selectedmask = cell_objmask{1}(:,:,ich);    % To Do: j-th image should be automatically selected
            selectedmask(flag) = 1;
            cell_objmask{1}(:,:,ich) = selectedmask;
        end
    end

end

