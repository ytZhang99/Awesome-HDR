function [ pseudowdr, err_std] = fn_pwdr( cell_lin_img, exptime, gamma )
%FN_PWDR Summary of this function goes here
%   Detailed explanation goes here

if nargin < 3
    gamma = 0.3;
end

if nargout > 1
    err_std = [];
end

pseudowdr = [];
for ich = 1:3
    voxel_lin_img = cat(3,cell_lin_img{ich}{:});
    A = (mean(voxel_lin_img,3).*exptime).^gamma;
    pseudowdr = cat(3, pseudowdr, A);
    
    if nargout > 1
        err_std = cat(3, err_std, max(voxel_lin_img-repmat(A,[1 1 size(voxel_lin_img,3)]), [], 3));
    end
end

if nargout > 1
    err_std = max(err_std,[],3);
end
end

