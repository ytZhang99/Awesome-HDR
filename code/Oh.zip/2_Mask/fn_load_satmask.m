function [ cell_satmask ] = fn_load_satmask( ldpath )
%FN_LOAD_SATMASK Summary of this function goes here
%   Detailed explanation goes here
    flist = ls(fullfile(ldpath, 'Sat*.png'));
    nimg = size(flist,1);
    cell_satmask = cell(1,nimg);
    for i = 1:nimg
        cell_satmask{i} = 1 - im2double(imread(fullfile(ldpath, flist(i,:))));
    end
    

end

