clear all; close all; clc;
addpath(genpath('.'));
RED = 1; GREEN = 2; BLUE = 3;

load('../Config.mat');
PROG.INPUTPATH = 'Radio';
PROG.EXPNAME = 'MC';


%% Parameter Setting
PROG.SATURATION = 3./255;
b_reference_for_objectmask = 0;


%% Process, either with or without scribble mask.
% Process;
Process_objmask;








