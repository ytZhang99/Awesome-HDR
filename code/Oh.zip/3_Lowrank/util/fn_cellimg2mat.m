function [ Datamat ] = fn_cellimg2mat( cell_imgs )
%FN_CELLIMG2MAT Summary of this function goes here
%   Detailed explanation goes here

    imgsize = size(cell_imgs{1});   imgsize = imgsize(1:2);
    nimg = length(cell_imgs);
    
    Datamat = zeros(imgsize(1)*imgsize(2), nimg);
    for j = 1:nimg
        curimg = cell_imgs{j};
        Datamat(:,j) = curimg(:);
    end
    
end

