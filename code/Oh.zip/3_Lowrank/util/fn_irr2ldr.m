function [ ldr ] = fn_irr2ldr( irr, CRF, exposure )
%FN_IRR2LDR Summary of this function goes here
%   Detailed explanation goes here
    maxv = max(CRF(:));
    exposed_energe = min(irr.*exposure, maxv);
    ldr = interp1(CRF, 0:1/255:1, exposed_energe, 'spline');
    

end

