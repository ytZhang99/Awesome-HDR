function [ cell_merged ] = fn_merge_masks( cell_sat_mask, cell_objmask, b_progation )
%FN_MERGE_MASKS Summary of this function goes here
%   Detailed explanation goes here
    

    cell_merged = cellfun(@(x,y) x&y, cell_sat_mask, cell_objmask, 'UniformOutput', false);
    
    if nargin > 2 && b_progation > 0
        nknownentries = cellfun(@(x) sum(x(:)), cell_objmask);
        [~, minidx] = min(nknownentries);
        [~, maxidx] = max(nknownentries);

        cell_merged{maxidx}(~cell_objmask{minidx}) = true;
    else
        nimgs = length(cell_objmask);
        idx = 1:nimgs;
        
        for i = 1:nimgs
            curidx = idx;
            curidx(i) = [];
            
            votemask = sum(double(cat(3, cell_objmask{curidx})), 3);
            flag = (votemask == 0);
            
            cell_merged{i}(flag) = true;
            
        end
        
%         for i = 1:length(cell_merged)
%             cell_merged{i}(~cell_objmask{i}) = true;
%         end
    end 
end

