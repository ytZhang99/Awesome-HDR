function [ SaturationMask ] = fn_gene_saturationmask( cell_img2d, saturationthr )
%FN_GENE_SATURATIONMASK Summary of this function goes here
%   If Saturated => false (outlier)
%   If not Saturated => true (inliner)
% 
    thr.under = saturationthr;
    thr.over = 1-saturationthr;

    nimgs = length(cell_img2d);
%     imsize = size(cell_img2d{1});
    
    
%     h = fspecial('gaussian', [15 15], 0.5);
%     cell_img2d = cellfun(@(x) imfilter(x, h), cell_img2d, 'UniformOutput', false);
    
    imgvol = cat(3,cell_img2d{:});
    darkmask = imgvol < thr.under;
    whitemask = imgvol > thr.over;
    
    satmask = darkmask | whitemask;
    
    darkmask = all(darkmask, 3);
    whitemask = all(whitemask, 3);
    
    
    SaturationMask = cell(1,nimgs);
    
    for i = 1:nimgs
        SaturationMask{i} = ~satmask(:,:,i);  % convert outlier mask to inlier mask
    end
    SaturationMask{1}(whitemask) = 1;
    SaturationMask{end}(darkmask) = 1;
    
end

