function [ RGB ] = fn_disp_unpackdata(R, G, B, CRF, scalefactor )
%FN_DISP_UNPACKDATA Summary of this function goes here
%   Detailed explanation goes here
    if nargin > 3 && scalefactor > 0
        R = fn_irr2ldr(R, CRF{1}, scalefactor);
        G = fn_irr2ldr(G, CRF{2}, scalefactor);
        B = fn_irr2ldr(B, CRF{3}, scalefactor);
    end
    
    RGB = cat(3,R,G,B);
    imshow( RGB );
    drawnow;
end
