function [ cell_imgs ] = fn_mat2cellimg( Datamat, imgsize )
%FN_MAT2CELLIMG Summary of this function goes here
%   Detailed explanation goes here

    nimg = size(Datamat,2);
    cell_imgs = cell(1,nimg);
    for j = 1:nimg
        cell_imgs{j} = reshape( Datamat(:,j), imgsize(1), imgsize(2) );
    end
end

