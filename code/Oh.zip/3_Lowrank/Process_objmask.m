%% Load data
curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
inputpath = fullfile(curpath, PROG.INPUTPATH);
savepath = fullfile(curpath, PROG.EXPNAME);
mkdir(savepath);

load(fullfile(inputpath, 'CRF.mat'));   % < CRF + Exposure time >
                                        % crf_ours, 
                                        % crf_mn
                                        % exposure
load(fullfile(inputpath, 'LinearizedImg.mat')); % < Original & Linearized Imgs >
                                                % cell_linearized_img{CH}{NIMG}
                                                % cellimgs{CH}{NIMG}

load(fullfile(curpath, 'Mask', 'Mask.mat'));    % < Object mask >
                                                % cell_objmask: cell(1,nimgs)

                                                
imsize = size(cellimgs{1}{1});
nimg = length(cellimgs{1});

expt_ref = exposure(round(end/2));


%% Saturation Mask
cell_NonSaturationMask = cell(1,3); % Inlier:1 , Outlier:0
for ich = RED:BLUE
    cell_NonSaturationMask{ich} = cell(nimg,1);
    for i = 1:nimg
        cell_NonSaturationMask{ich}{i} = cell_objmask{i}(:,:,ich);
    end
end

%% Display
for i = 1:nimg
    ich = 1;
    R = cell_NonSaturationMask{ich}{i}; ich = ich+1;
    G = cell_NonSaturationMask{ich}{i}; ich = ich+1;
    B = cell_NonSaturationMask{ich}{i}; 
    curmask = fn_disp_unpackdata( double(R), double(G), double(B) ); 
    imwrite(curmask, fullfile(savepath, ['M' num2str(i) '.png']) );
end

%% Low-rank and sparse decomposition
cell_Lowrank_2D = cell(1,3);
cell_Sparse_2D = cell(1,3);
tic;
for ich = RED:BLUE
	D = fn_cellimg2mat(cell_linearized_img{ich});   % Vectorize
	M = fn_cellimg2mat(cell_NonSaturationMask{ich});   % Vectorize
	D = D.*expt_ref;
	Omega = find(logical(M));
	
	[L, E] = MC_CPCP(D, Omega, 1.0/sqrt( imsize(1)*imsize(2) ), 1 );

	cell_Lowrank_2D{ich} = fn_mat2cellimg(L, imsize); % Cell
	cell_Sparse_2D{ich} = fn_mat2cellimg(E, imsize); % Cell
end
toc;
save(fullfile(savepath, 'L_E.mat'), 'cell_Lowrank_2D', 'cell_Sparse_2D',  'cell_NonSaturationMask');
% load(fullfile(savepath, 'L_E.mat'), 'cell_Lowrank_2D', 'cell_Sparse_2D',  'cell_NonSaturationMask');



%% Display
for i = 1:nimg
    ich = 1;
    R = cell_Lowrank_2D{ich}{i}; ich = ich+1;
    G = cell_Lowrank_2D{ich}{i}; ich = ich+1;
    B = cell_Lowrank_2D{ich}{i}; 
    curlowrank = fn_disp_unpackdata(R, G, B, crf_ours, exposure(i)./expt_ref ); %exposure(i)
    imwrite(curlowrank, fullfile(savepath, ['L' num2str(i) '.png']) );
    
    ich = 1;
    R = cell_Sparse_2D{ich}{i};     ich = ich+1;
    G = cell_Sparse_2D{ich}{i};     ich = ich+1;
    B = cell_Sparse_2D{ich}{i};     
    cursparse = fn_disp_unpackdata(R+0.5, G+0.5, B+0.5 );
    imwrite(cursparse, fullfile(savepath, ['E' num2str(i) '.png']) );
end


