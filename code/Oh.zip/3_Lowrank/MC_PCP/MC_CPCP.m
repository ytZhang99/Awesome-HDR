function [L, S, nIter] = MC_CPCP(D, Omega, lambda, br1sc)
% Omega : Indeces of the known entries
% OmegaC : Missing entries
    [m,n] = size(D) ;

    temp = true(m*n,1) ;
    temp(Omega) = 0 ;
    nKnown = length(Omega);
	Omega = (temp == 0);
    OmegaC = (temp == 1);
    
    tolerance = 5e-6 ;
    tolerance_alt = 1e-2 ;
    tolerance_apg = 1e-3 ;

    maxIter = 500;
    maxIter_alt = 10;
    maxIter_apg = 5;

    rho_0 = 1.9;
    rho = rho_0;
    
    L = D;
    P_D = D(Omega);
    rankL = 0 ;
    Y = zeros(nKnown,1) ; 
    S = zeros(nKnown,1) ; 

    normD = norm(D,2) ;
    normd = norm(D,'fro');
    mu = 1.25/normD ;
    mu_max = 1e6;

    converged_main = 0 ;
    
    nIter = 0 ;
    P_adj_D_Y_S = zeros(m,n); 
    while ~converged_main
        nIter = nIter + 1 ;
        n_svd = 0 ;
        converged_alt = 0 ;
        nIter_alt = 0 ;

        muInv = 1/mu ;
        Y_scaled = muInv*Y ;
        lambdaMuInv = lambda*muInv ;

        L_old = L ;
        S_old = S ;
		D_muinvY = P_D + Y_scaled ;
		
        while ((~converged_alt) && (nIter_alt < maxIter_alt))
            nIter_alt = nIter_alt + 1 ;

            L_old_alt = L ;
            S_old_alt = S ;

			% Sparsity
            Gmattemp1 = D_muinvY-L(Omega);
            S = max(Gmattemp1-lambdaMuInv,0) + min(Gmattemp1+lambdaMuInv,0);

			% Low-rank
            D_muinvY_S = D_muinvY - S;

            converged_apg = 0 ;
            nIter_apg = 0 ;
            t1 = 1 ; 
            
            Z = L;
            P_adj_D_Y_S(Omega) = D_muinvY_S;
            while ~converged_apg
                nIter_apg = nIter_apg + 1 ;

                L_old_apg = L;

                L = P_adj_D_Y_S;
                L(OmegaC) = Z(OmegaC);
                
                [GmatU, GmatS, GmatV] = svd(L, 0);
                GmatdiagS = diag(GmatS) ;
                prevS = GmatdiagS;
                n_svd = n_svd + 1 ;
                rankL = length(GmatdiagS > muInv) ;
                if br1sc
                    GmatdiagS = [GmatdiagS(1); max(0,GmatdiagS(2:rankL) - muInv) ];
                    L = GmatU(:,1:rankL)*(diag( GmatdiagS  )*GmatV(:,1:rankL)') ;
                else
                    GmatdiagS = max(0,GmatdiagS(1:rankL) - muInv);
                    L = (GmatU(:,1:rankL)*diag( GmatdiagS ) )*GmatV(:,1:rankL)' ;
                end

                Grad_apg = L - L_old_apg;
                STC = sqrt(sq_frobenius(Grad_apg))/normd;
                if  (STC < tolerance_apg) || (nIter_apg >= maxIter_apg)
                    converged_apg = 1 ;
                end
                t2 = 0.5*(1+sqrt(1+4*t1*t1)) ;
                Z = L + ((t1-1)/t2)*(Grad_apg) ;
                t1 = t2 ;
            end
            
			Dev_L = sq_frobenius(L_old_alt-L);
			Dev_S = sq_frobenius(S_old_alt-S);
            STC = sqrt(max(Dev_L, Dev_S))/normd;
            disp(['Inner: ' num2str(nIter_alt) ' ] Rel[ ' num2str(STC) ' ]    ']);
            if (STC < tolerance_alt)
                converged_alt = 1 ;
            end
        end
        
        Grad = P_D - L(Omega) - S;
        Y= Y + mu*(Grad) ;
        
        normL = sq_frobenius(L_old-L);
        normS = sq_frobenius(S_old-S);
        
        if  mu*sqrt(max(normL,normS))/normd < 5e-4
            mu = min(rho*mu, mu_max) ;
        end
                
        stopcriterion = norm(Grad,'fro')/normd;
        if (stopcriterion < tolerance) || (nIter >= maxIter)
            converged_main = 1 ;
        end
		
        sparsityS = sum(abs(S(:))>lambdaMuInv) ;
        disp(['Iter ' num2str(nIter) ' rank(L) ' num2str(rankL) ' ||S||_0 ' num2str(sparsityS) ...
            ' #svd ' num2str(n_svd) ' Rel[ ' num2str(stopcriterion) ' ]']) ;
    end
    S = D-L;
end


function sqnorm = sq_frobenius(M)
    sqnorm = sum( M(:).^2 );
end
