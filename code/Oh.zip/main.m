clear all;clc;
PROG.DATAPATH = '../Data';
PROG.DATANAME = 'Santa';
% PROG.RadioMethod = 'Linear';
PROG.RadioMethod = 'JYLEE';
% PROG.RadioMethod = 'MN';
PROG.saturation_thr = 1/255;



save('Config.mat', 'PROG');
%% Process 1. Radiometric Calibration
cd 1_Radiometric;
if strcmp(PROG.RadioMethod, 'Linear')
    main_linear;	% Without calibration
else
    main;			% With calibration (Not provided yet)
end
cd ..;

%% Process 2. Mask Generation
cd 2_Mask;
main;
cd ..;
% return;

%% Process 3. Rank Minimization
cd 3_Lowrank;
main;
cd ..;

%% Process 4. Simple Composition
cd 4_Composition;
main;
cd ..;