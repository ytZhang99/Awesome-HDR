clear all; close all; clc;
load('../Config.mat');
PROG.INPUTPATH = 'MC';
PROG.EXPNAME = 'HDR';

curpath = fullfile(PROG.DATAPATH, PROG.DATANAME);
inputpath = fullfile(curpath, PROG.INPUTPATH);
savepath = fullfile(curpath, PROG.EXPNAME);
mkdir(savepath);

%% Load Low-rank images
load(fullfile(inputpath, 'L_E.mat'), 'cell_Lowrank_2D');

%% Composite to HDR
HDRcell = cell(1,3);
for ich = 1:3
    Tensor = cat(3,cell_Lowrank_2D{ich}{:});
    HDRcell{ich} = mean(Tensor,3);
    HDRcell{ich} = max(HDRcell{ich},0);
end
HDR = cat(3,HDRcell{:});
hdrwrite(HDR, fullfile(savepath, 'MC.hdr'));

disp(['HDR is generated at ' fullfile(savepath, 'MC.hdr')]);
